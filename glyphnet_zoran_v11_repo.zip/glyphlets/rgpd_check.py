# glyphlets/rgpd_check.py
class GlyphletRGPD:
    name = "RGPD Compliance"

    def check(self, context):
        # Exemple simplifié : blocage si données sensibles détectées
        if "ssn" in context or "patient_name" in context:
            return False
        return True
