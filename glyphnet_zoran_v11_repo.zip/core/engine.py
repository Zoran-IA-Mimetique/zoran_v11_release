# core/engine.py
class GlyphNetEngine:
    def __init__(self):
        self.glyphlets = []

    def register(self, glyphlet):
        self.glyphlets.append(glyphlet)

    def execute(self, context):
        for g in self.glyphlets:
            if not g.check(context):
                raise Exception(f"Violation detected: {g.name}")
