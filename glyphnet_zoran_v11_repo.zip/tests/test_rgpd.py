# tests/test_rgpd.py
import unittest
from glyphlets.rgpd_check import GlyphletRGPD

class TestRGPD(unittest.TestCase):
    def test_rgpd_compliance(self):
        g = GlyphletRGPD()
        self.assertTrue(g.check({"data": "normal"}))
        self.assertFalse(g.check({"patient_name": "Alice"}))

if __name__ == "__main__":
    unittest.main()
